-----------------------------------------------------------------
 mob.txt Thai A-Server0628 by Kalen
-----------------------------------------------------------------
 Files seperated by L0ne_W0lf
 Directory Structure by L0ne_W0lf