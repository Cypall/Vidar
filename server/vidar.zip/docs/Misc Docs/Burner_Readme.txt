Guild Castle
"T r e a s u r e   B o x"


	This is my own version of the treasure box that can be found inside the master room of the Guild Castle.
	
	This treasure box is only set for every 1 hour. Meaning after an hour there will be another treasure box. To set it on 24 hours like on the original version of the game change the time of the respawn rate.

	 Hour/s		time1		time2

	1 hour   -     3600000         1800000
	2 hour   -     7200000	       5400000
	3 hour   -    10800000	       9000000
	....		...		....
	....		...		....
	....		...		....
	24 hour  -    86400000	      84600000

	I might be wrong on my computation. Just check it. Here's the formula below.

Formula:

	time1 ==  hour = 60 * (hour/s) * 60000
	time2 ==  hour = 60 * (hour/s) * 30000

	Hope you like it. Please do not remove my nick on using this. I would really appreciate it. :)


"Burner"
doing my best to support Vidar.