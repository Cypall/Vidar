Original Readme.txt infomation:
Folders added by Soulfang.
eWeiss Project 2003

All files in here will be read and added. 
Please keep directories clean!!

 Additional Information:

 - The NPCs stored in this directory, unless noted otherwise
 are the intellectual property of the creator.
 - Some files may not be labeled properly, if it is not, 
 feel free to contact me on the Vidar forums. (Link in /docs/
 folder.)
 - Some scripts are translated versions of original Weiss
 scripts files.
 Furthermore--
 Comments are done in the form of //'s before OR in a line
 NPCs will NOT function if there is a space in the script.
 Example:
  msg "Hello, this is an example.";
  <blank line>
  msg "This is an improper script.";
