Casino Scripts v2.0
Don't remove the headers, if you are to edit please give credit to where it belongs.


Installation::
 - Put all the *.txt files into your script\misc\ folder.

Features::
 - Black Jack
 - Slot Machines
 - Token Exchanger
 - Pair Game
 - Guess High-Low
 - Roulette
 - 3 Card Monte

Next Release::
 - Craps

Notes::
 - Minor Fixes
 - For the slot machines I have used Fur_of_Goat as tokens.. ONLY for testing purposes
   if you are to continue to use this remember to change its values in your item_db.txt
   values such as its weight set to 0, sell price set to 0
 - The prizes on the slot machines get rare as they play the higher amount slots
   you can edit the prizes to of your liking.
 - In the Roulette game there is 2 options(odd\even and row) that is currently being worked on so 
   just wait till the next release for it to be fixed :P
 - Report problems\bugs or if have an idea illogik@verizon.net