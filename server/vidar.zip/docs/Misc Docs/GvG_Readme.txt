npc_*_gflags.txt info:
----------------------------------------------------------------------------------------
 Edited for dWeiss GVG Project - The Harbinger // Makenza
 Edited again by L0ne_W0lf to include option to warp to guild base
----------------------------------------------------------------------------------------

*_cas*.txt info:
----------------------------------------------------------------------------------------
 prt_cas01.txt - The Harbinger.

 Remaining guild houses filled in and done by me, names provided 
 by Makenza
----------------------------------------------------------------------------------------

GVG_Mob_Summon.txt info:
----------------------------------------------------------------------------------------
 Empty house summons incoperated by L0ne_W0lf.
 Monster data gotten from ASB Aegis.
----------------------------------------------------------------------------------------