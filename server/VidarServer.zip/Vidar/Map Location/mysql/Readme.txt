================================
	Vidar Tools 0.2 Alpha
================================

Changelogs:-

- 21/01/2004

Version 0.2 Alpha/Test Version

* Added MySQL Setup Wizard
* Fixed 'Close Window' button in Server Control

Version 0.1 Alpha/Test Version

* Added Server Configurator feature
* Added Server Control feature
* Added Server Status feature
* Added Account Editor

================
Instructions
================

This tool is still in alpha stage, which means there might be errors and bugs lying around which might corrupt your data.

Always backup first before this tool. The files that are edited by this tool currently is
1) \Vidar\Vidar.ini
2) \Vidar\database\id_table.txt


where \Vidar\ is the path where u installed Vidar (or pointed when the tool asked for it).
and \VToolsPath is where u put the editor.

Currently, the tool assumes the following paths and filename for the files

1) \Vidar\Vidar.ini
2) \Vidar\database\id_table.txt
3) \VToolsPath\vTools\databases\MapInfo.txt
4) \VToolsPath\vTools\databases\itemDesc.txt
5) \VToolsPath\vTools\databases\SkillDescTable.txt
6) \VToolsPath\vTools\databases\SkillNameTable.txt
7) \VToolsPath\vTools\maps <-- place the map preview files (not darkWeiss .dwm or RO's .gat)  in this directory

The map files can be in either in bitmap(.bmp), jpeg, gif or metafile (or even icon format??). The name of the map preview file
have to be the name of the area (for example, for Prontera Field 7 (prt_fild07), put prt_fild07.jpg, not prt_fild07.gat.jpg)
..and the maps need to have exact aspect ratio of the original maps used in client. It is recommended that you use the map 
preview files included with your client.


----------------
 Server Control
----------------

Backup tool will copy the following directories..

1) \MySQLPath\glogin\
2) \MySQLPath\dwcharacter\
3) \MySQLPath\dwglobal\


into the folder with name 'Backup', which is located in subdirectory 'vTools'( \vToolsPath\vTools\Backup\ )

For database copying, Backup tool will rely on MyODBC for connections. All 3 databases ( glogin, dwcharacter and dwglobal )
will be copied, with 'bk_' appended to the beginning of their name in the backup SQL server (bk_glogin, bk_dwcharacter, bk_dwglobal )


Currently, the markers that are supported in message to be sent to connected players are :-

$TimeToBackup - time left before next backup (in minutes)
$RestoreTime - the time when the server will restart ( using server time )
$BackupDuration - the duration the server will be offline

the caps doesn't matter, it can be $tImeTOBacKUp for example, but there must not be any extra characters in the markers.
If you have any other suggestions for other helpful markers, let me know at the forums ;)

Example of message :-

"The server will be offline in $TimetoBackup for maintenance purposes.It will be back at $RestoreTime ."

...without quotes. Please be reminded that there is a limitation of only 100 characters for the message.


The Error Detector tools on default will attempt to close all dialog boxes when enabled. If you want to actually see the errors,
disable it. It only close a popup per interval, so if the error is continous (spawns lots of error messages), probably it's better if you close the error dialogs yourself. 
Currently the server information and IP changes detection is updated on 5 seconds interval.

---------------------
 Server Configurator
---------------------

When starting Login and Character server from within Vidar Tools, it will has the priority as set in Settings in 'Process Priority' tab. Zone server
will start with Priority settings in Vidar.ini file. To apply priority changes immediately, use 'Current' settings in 'Process Priority' tab
and click on 'Apply Changes to Priority'

Again, please backup your data files before using this tools.

----------------------
 MySQL Setup Wizard
----------------------

For connection test, the wizard will try to connect with no username/password, which will use user ''@localhost which exists
on default installation. If you removed this user, the connection test might failed, but the rest of the setup process will
still works provided you supplied an account with proper privileges in Step 2. The user in Step 2 need to have the following 
privileges, set to global privileges

1) CREATE
2) DROP
3) GRANT

In later MySQL version, the privilege SHOW DATABASES is also needed.




If you have any suggestion or found a bug, please feel free to inform me at the forums. 

~:Vidar Forums:~
http://vidar.sigh.org/forum/



Lastly, please enjoy!

Cryosphere.